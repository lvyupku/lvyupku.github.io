# Weibull-to-Erlang Approximation

This repository provides a **Python implementation** of the **moment-matching method**
for approximating Weibull distributions with **Increasing Failure Rate (IFR)**
by Erlang distributions. The implementation reproduces the results in **Table I**
of our paper: *[Paper Title]*.

## Features
- Approximate Weibull distribution parameters (γ, α) by Erlang parameters (M, λ)
- Based on the **moment-matching** technique
- Reproduces **Table I** results from the paper

## Installation
```bash
git clone https://github.com/<your_username>/Weibull-to-Erlang.git
cd Weibull-to-Erlang
pip install -r requirements.txt
```

## Usage
### Example: Approximation of Weibull Parameters
```bash
python weibull_to_erlang.py
```

Sample output:
```
       γ        α      M           λ
--------------------------------------
  1.1593   17.0000     2       0.1239
  1.1229  664.0000     2       0.0031
  1.0366   15.0000     2       0.1353
  1.2452   16.0000     5       0.3352
 28.6487    9.0000    20       2.2652
  2.8232   23.0000     3       0.1464
```

## Reference
If you use this code, please cite our paper:

> **[Paper Title]**  
> *IEEE Transactions on Aerospace and Electronic Systems, 2025.*

## License
MIT License © 2025 Yu Lu
