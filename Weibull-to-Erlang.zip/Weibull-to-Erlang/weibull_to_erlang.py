#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Approximate Weibull distribution with IFR by Erlang distribution
using the moment-matching method.

Author: Yu Lu
Date: 2025-09-11
"""

import numpy as np
from scipy.special import gamma as gamma_func

def weibull_to_erlang(shape_gamma, scale_alpha):
    """
    Approximate a Weibull distribution with an Erlang distribution
    using the moment-matching method.

    Parameters
    ----------
    shape_gamma : float
        Shape parameter γ of the Weibull distribution.
    scale_alpha : float
        Scale parameter α of the Weibull distribution.

    Returns
    -------
    M : int
        Number of Erlang stages.
    lam : float
        Rate parameter λ of the Erlang distribution.
    """
    # First two moments of Weibull distribution
    mean_weibull = scale_alpha * gamma_func(1 + 1.0 / shape_gamma)
    var_weibull = (scale_alpha ** 2) * (
        gamma_func(1 + 2.0 / shape_gamma) -
        (gamma_func(1 + 1.0 / shape_gamma)) ** 2
    )

    # Erlang parameters via moment-matching
    M = int(round(mean_weibull ** 2 / var_weibull))  # number of stages
    lam = M / mean_weibull                           # Erlang rate parameter

    return M, lam

if __name__ == "__main__":
    # Example test cases based on Table I in the paper
    weibull_params = [
        (1.1593, 17),
        (1.1229, 664),
        (1.0366, 15),
        (1.2452, 16),
        (28.6487, 9),
        (2.8232, 23)
    ]

    print(f"{'γ':>8} {'α':>8} {'M':>6} {'λ':>12}")
    print("-" * 40)

    for gamma_val, alpha_val in weibull_params:
        M, lam = weibull_to_erlang(gamma_val, alpha_val)
        print(f"{gamma_val:8.4f} {alpha_val:8.4f} {M:6d} {lam:12.4f}")
