# Example script to reproduce Table I from the paper

from weibull_to_erlang import weibull_to_erlang

weibull_params = [
    (1.1593, 17),
    (1.1229, 664),
    (1.0366, 15),
    (1.2452, 16),
    (28.6487, 9),
    (2.8232, 23)
]

print(f"{'γ':>8} {'α':>8} {'M':>6} {'λ':>12}")
print("-" * 40)

for gamma_val, alpha_val in weibull_params:
    M, lam = weibull_to_erlang(gamma_val, alpha_val)
    print(f"{gamma_val:8.4f} {alpha_val:8.4f} {M:6d} {lam:12.4f}")
